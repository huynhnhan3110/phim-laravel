
<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center">
      <div class="col-md-12" style="margin-top: 10px">
         <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
               <?php if(!isset($movie)): ?>
               Thêm phim
               <?php else: ?>
               Sửa phim
               <?php endif; ?>
               <a href="<?php echo e(route('movie.index')); ?>"  class="btn btn-sm btn-primary">Xem danh sách</a>
            </div>
            <div class="card-body">
               <?php if(session('status')): ?>
               <div class="alert alert-success" role="alert">
                  <?php echo e(session('status')); ?>

               </div>
               <?php endif; ?>
               <?php if(isset($movie)): ?>
               <?php echo Form::open(['route' => ['movie.update',$movie->id], 'method'=>'PUT', 'enctype'=>'multipart/form-data']); ?>

               <?php else: ?>
               <?php echo Form::open(['route' => 'movie.store', 'method'=>'POST','enctype'=>'multipart/form-data']); ?>

               <?php endif; ?>
               <div class="form-group">
                  <?php echo Form::label('title', 'Title',[]); ?>

                  <?php echo Form::text('title',isset($movie) ? $movie->title : null, ['placeholder' => 'Nhập nội dung','class' => 'form-control','id' => 'slug','onkeyup'=>'ChangeToSlug()']); ?>

               </div>
               <div class="form-group">
                  <?php echo Form::label('slug', 'Slug',[]); ?>

                  <?php echo Form::text('slug',isset($movie) ? $movie->slug : null, ['placeholder' => 'Nhập nội dung','class' => 'form-control','id' => 'convert_slug']); ?>

               </div>
               <div class="form-group">
                  <?php echo Form::label('description', 'Description',[]); ?>

                  <?php echo Form::textarea('description',isset($movie) ? $movie->description : null, ['style'=>'resize:none','placeholder' => 'Nhập nội dung','class' => 'form-control','id' => 'description']); ?>

               </div>

               <div class="form-group">
                  <?php echo Form::label('category', 'Category',[]); ?>

                  
                  <?php echo Form::select('category_id', $category,isset($movie) ? $movie->category_id : '', ['class'=>'form-control']); ?>

                  
               </div>
               <div class="form-group">
                  <?php echo Form::label('genre', 'Genre',[]); ?>

                  
                  <?php echo Form::select('genre_id', $genre,isset($movie) ? $movie->genre_id : '', ['class'=>'form-control']); ?>

                  
               </div>
               <div class="form-group">
                  <?php echo Form::label('country', 'Country',[]); ?>

                  
                  <?php echo Form::select('country_id',$country,isset($movie) ? $movie->country_id :'', ['class'=>'form-control']); ?>

                  
               </div>

                <div class="form-group">
                  <?php echo Form::label('Image', 'Chọn hình ảnh',[]); ?>

                  <br>
                  <?php echo Form::file('image', ['class'=> 'image_file']); ?>

                  <?php if(isset($movie)): ?>
                     <img width="150px" src="<?php echo e(asset('uploads/movie/'.$movie['image'])); ?>">
                  <?php endif; ?>
               </div>
               <div class="form-group">
                  <?php echo Form::label('hot', 'Phim Hot',[]); ?>

                  <?php echo Form::select('phimhot', ['0' => 'Không', '1' => 'Có'], isset($movie) ? $movie->phimhot : '', ['class'=>'form-control']); ?>

               </div>

               <div class="form-group">
                  <?php echo Form::label('status', 'Status',[]); ?>

                  <?php echo Form::select('status', ['1' => 'Hiện', '0' => 'Ẩn'], isset($movie) ? $movie->status : '', ['class'=>'form-control']); ?>

               </div>
               <center>
                  <?php if(!isset($movie)): ?>
                  <?php echo Form::submit('Thêm phim', ['class' => 'btn btn-primary']); ?>

                  <?php else: ?>
                  <?php echo Form::submit('Cập nhật phim', ['class' => 'btn btn-primary']); ?>

                  <?php endif; ?>
                   <a class="btn btn-secondary" href="<?php echo e(route('movie.index')); ?>">Trở về danh sách</a>
               </center>
               <?php echo Form::close(); ?>

            </div>
         </div>
      </div>

   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/admincp/movie/form.blade.php ENDPATH**/ ?>