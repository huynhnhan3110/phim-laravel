
<?php $__env->startSection('content'); ?>
<div class="container page_name" id="category-page">
   <div class="row justify-content-center">
      <div class="col-md-12" style="margin-top: 10px">
         <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
               <?php if(!isset($category)): ?>
               Thêm danh mục
               <?php else: ?>
               Sửa danh mục
               <?php endif; ?>

               <a href="<?php echo e(route('category.index')); ?>"  class="btn btn-sm btn-primary">Xem danh sách</a>
            </div>
            <div class="card-body">
               <?php if(session('status')): ?>
               <div class="alert alert-success" role="alert">
                  <?php echo e(session('status')); ?>

               </div>
               <?php endif; ?>
               <?php if(isset($category)): ?>
               <?php echo Form::open(['route' => ['category.update',$category->id], 'method'=>'PUT']); ?>

               <?php else: ?>
               <?php echo Form::open(['route' => 'category.store', 'method'=>'POST']); ?>

               <?php endif; ?>
               <div class="form-group">
                  <?php echo Form::label('title', 'Title',[]); ?>

                  <?php echo Form::text('title',isset($category) ? $category->title : null, ['placeholder' => 'Nhập nội dung','class' => 'form-control','id' => 'slug','onkeyup'=>'ChangeToSlug()']); ?>

               </div>
               <div class="form-group">
                  <?php echo Form::label('slug', 'Slug',[]); ?>

                  <?php echo Form::text('slug',isset($category) ? $category->slug : null, ['placeholder' => 'Nhập nội dung','class' => 'form-control','id' => 'convert_slug']); ?>

               </div>
               <div class="form-group">
                  <?php echo Form::label('description', 'Description',[]); ?>

                  <?php echo Form::textarea('description',isset($category) ? $category->description : null, ['style'=>'resize:none','placeholder' => 'Nhập nội dung','class' => 'form-control','id' => 'description']); ?>

               </div>
               <div class="form-group">
                  <?php echo Form::label('textStatus', 'Status',[]); ?>

                  <?php echo Form::select('status', ['1' => 'Hiện', '0' => 'Ẩn'], isset($category) ? $category->status : null, ['placeholder' => 'Chọn trạng thái...','class'=>'form-control']); ?>

               </div>
               <center>
               <?php if(!isset($category)): ?>
                  <?php echo Form::submit('Thêm danh mục', ['class' => 'btn btn-primary']); ?>

                  <a class="btn btn-secondary" href="<?php echo e(route('category.index')); ?>">Trở về danh sách</a>
               <?php else: ?>
                  <?php echo Form::submit('Cập nhật danh mục', ['class' => 'btn btn-primary']); ?>

                  <a class="btn btn-secondary" href="<?php echo e(route('category.index')); ?>">Trở về danh sách</a>
               <?php endif; ?>
               </center>
               <?php echo Form::close(); ?>

            </div>
         </div>
         
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/admincp/category/form.blade.php ENDPATH**/ ?>