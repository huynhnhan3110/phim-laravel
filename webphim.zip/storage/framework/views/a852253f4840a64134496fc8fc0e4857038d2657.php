
<?php $__env->startSection('content'); ?>
<div class="container page_name" id="category-page">
   <div class="row justify-content-center">
      <div class="col-md-12" style="margin-top: 10px">
         <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">Danh sách các danh mục
            <a href="<?php echo e(route('category.create')); ?>"  class="btn btn-sm btn-primary">Thêm danh mục</a></div>
            <div class="card-body">
               <table class="table" id="datatables_category">
                  <thead>
                     <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Slug</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                     </tr>
                  </thead>
                  <tbody id='sortable'>
                     <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr id='<?php echo e($cate->id); ?>'>
                        <th scope="row"><?php echo e($key+1); ?></th>
                        <td><?php echo e($cate['title']); ?></td>
                        <td><?php echo e($cate['description']); ?></td>
                        <td><?php echo e($cate['slug']); ?></td>

                        <td>
                           <?php if($cate['status']): ?>
                           Hiển thị
                           <?php else: ?>
                           Chưa hiển thị
                           <?php endif; ?>
                        </td>
                        <td>
                           <?php echo Form::open(['route' => ['category.destroy',$cate['id']],'method'=>'DELETE','onsubmit'=> 'return confirm("Chắc chắn muốn xóa chứ ?")']); ?>

                           <?php echo Form::submit('Xóa', ['class' => 'btn btn-danger']); ?>

                           <?php echo Form::close(); ?>

                           <a href="<?php echo e(route('category.edit',$cate['id'])); ?>" class="btn btn-secondary">Sửa</a>
                        </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/admincp/category/index.blade.php ENDPATH**/ ?>