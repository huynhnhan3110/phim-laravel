
<?php $__env->startSection('content'); ?>
<div class="container page_name" id="country-page">
   <div class="row justify-content-center">
      <div class="col-md-12" style="margin-top: 10px">
         <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">Danh sách các quốc gia
               <a href="<?php echo e(route('country.create')); ?>"  class="btn btn-sm btn-primary">Thêm quốc gia</a>
            </div>
            <div class="card-body">
               <table class="table" id="datatables_country">
                  <thead>
                     <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Slug</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                     </tr>
                  </thead>
                  <tbody id='sortable'>
                     <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr id="<?php echo e($coty['id']); ?>">
                        <th scope="row"><?php echo e($key+1); ?></th>
                        <td><?php echo e($coty['title']); ?></td>
                        <td><?php echo e($coty['description']); ?></td>
                        <td><?php echo e($coty['slug']); ?></td>

                        <td>
                           <?php if($coty['status']): ?>
                           Hiển thị
                           <?php else: ?>
                           Chưa hiển thị
                           <?php endif; ?>
                        </td>
                        <td>
                           <?php echo Form::open(['route' => ['country.destroy',$coty['id']],'method'=>'DELETE','onsubmit'=> 'return confirm("Chắc chắn muốn xóa chứ ?")']); ?>

                           <?php echo Form::submit('Xóa', ['class' => 'btn btn-danger']); ?>

                           <?php echo Form::close(); ?>

                           <a href="<?php echo e(route('country.edit',$coty['id'])); ?>" class="btn btn-secondary">Sửa</a>
                        </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/admincp/country/index.blade.php ENDPATH**/ ?>