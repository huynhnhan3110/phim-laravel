
<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center">
      <div class="col-md-12" style="margin-top: 10px">
         <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">Danh sách các phim
               <a href="<?php echo e(route('movie.create')); ?>"  class="btn btn-sm btn-primary">Thêm phim</a>
            </div>
            <div class="card-body">
               <table class="table" id="datatables_movie">
                  <thead>
                     <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Image</th>
                        <th scope="col">Slug</th>
                        <th scope="col">Category</th>
                        <th scope="col">Genre</th>
                        <th scope="col">Country</th>
                        <th scope="col">Hot</th>
                        <th scope="col">Active/Inactive</th>
                        <th scope="col">Action</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <th scope="row"><?php echo e($key+1); ?></th>
                        <td><?php echo e($mov['title']); ?></td>
                        <td><img width="90%" src="<?php echo e(asset('uploads/movie/'.$mov['image'])); ?>"></td>
                        <td><?php echo e($mov->slug); ?></td>
                        <td>
                          <?php echo e($mov->category->title); ?>

                        </td>
                        <td><?php echo e($mov->genre->title); ?></td>
                        <td><?php echo e($mov->country->title); ?></td>
                        <td>
                           <?php if($mov['phimhot'] == 1): ?>
                              Có
                           <?php else: ?>
                              Không
                           <?php endif; ?>
                        </td>
                        <td>
                           <?php if($mov['status']): ?>
                           Active
                           <?php else: ?>
                           Inactive
                           <?php endif; ?>
                        </td>
                        <td>
                           <?php echo Form::open(['route' => ['movie.destroy',$mov['id']],'method'=>'DELETE','onsubmit'=> 'return confirm("Chắc chắn muốn xóa chứ ?")']); ?>

                           <?php echo Form::submit('Xóa', ['class' => 'btn btn-danger']); ?>

                           <?php echo Form::close(); ?>

                           <a href="<?php echo e(route('movie.edit',$mov['id'])); ?>" class="btn btn-secondary">Edit</a>
                        </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>

   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/admincp/movie/index.blade.php ENDPATH**/ ?>